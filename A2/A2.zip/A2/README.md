# Flask RESTful API for Item Management

This is a simple Flask-based RESTful API for managing a list of items. The API allows you to perform basic CRUD (Create, Read, Update, Delete) operations on items. It also includes error handling for common HTTP error codes and supports Cross-Origin Resource Sharing (CORS).

## Table of Contents
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
- [API Endpoints](#api-endpoints)
- [Usage Examples](#usage-examples)
- [Running with a React App](#running-with-a-react-app) 


## Prerequisites
Before running the API, make sure you have the following prerequisites installed:
- Python 3.x
- Flask
- Flask-CORS (for enabling Cross-Origin Resource Sharing)
- Node.js (for the React app)

Note: The node_modules directory used by the React app is excluded from this repository. You can easily install the required dependencies for the React app by running the following command inside your React project directory:
```bash
npm install
```


You can install Flask and Flask-CORS using `pip`:
```bash
pip install Flask Flask-CORS
```

## Getting Started
1. Run the Flask application:
- locate the server.py and run
```bash
python app.py
```
The API will start running locally on `http://127.0.0.1:5000`.


2. Run the react app: 
- Go into the todo-client file and run 
```bash
npm start
```
The react app will start running on `http://localhost:3000/`.


## API Endpoints
- `GET /api/items/`: Retrieve a list of all items.
- `GET /api/items/<int:item_id>`: Retrieve a single item by its ID.
- `POST /api/items/`: Create a new item.
- `PUT /api/items/<int:item_id>`: Update an existing item.
- `DELETE /api/items/<int:item_id>`: Delete an item by its ID.

## Usage Examples
You can interact with the API using tools like `curl` or by using the React app `http://localhost:3000/`
### Example 1: Retrieve All Items 
```bash
curl -X GET http://localhost:5000/api/items/
```

### Example 2: Create a New Item
```bash
curl -X POST -H "Content-Type: application/json" -d '{"name": "New Item"}' http://localhost:5000/api/items/
```

### Example 3: Update an Item (Mark as Done)
```bash
curl -X PUT -H "Content-Type: application/json" -d '{"done": true}' http://localhost:5000/api/items/1
```

### Example 4: Delete an Item
```bash
curl -X DELETE http://localhost:5000/api/items/1
```

## Running with a React App  
To integrate this Flask API with a React app, you can use the React app's local host,  running on `http://localhost:3000/`. You can retrieve items from the API by making GET requests to `http://127.0.0.1:5000/api/items/` and retrieve a specific item by ID by making GET requests to `http://localhost:5000/api/items/+id`.



