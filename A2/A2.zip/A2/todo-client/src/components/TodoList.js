/*
    TodoForm.js manages the input field for adding new tasks or editing existing ones and collaborates with 
    Todo.js to handle the submission of updates and 
*/

import React, { useState, useEffect } from 'react';
import TodoForm from './TodoForm';
import Todo from './Todo';

// Define the base URL for API requests
const API_BASE_URL = 'http://127.0.0.1:5000/api/items/';

function TodoList() {
    // Initialize state for managing the list of todos
    const [todos, setTodos] = useState([]);                             // Manage todos state as an array
    const [errorMessage, setErrorMessage] = useState('');               // Store error messages
    const [duplicateTodoError, setDuplicateTodoError] = useState('');   // Store duplicate todo error message


    // Function to handle errors and display alerts
    function handleError(error, errorMessage) {
        console.error(error.message);                                    // Log the error message to the console
        setErrorMessage(errorMessage);                                   // Set the error message in the state
    }

    // Function to log the server response
    const logServerResponse = (data) => {
        console.log("Server response:", data);
    };

    async function fetchAndUpdateTodos() {
        try {
            // Send a GET request to the server to fetch todos
            const response = await fetch(API_BASE_URL);
            if (!response.ok) {
                throw new Error('Failed to fetch todos from the server.');
            }
            const data = await response.json();

            // Log server response
            logServerResponse(data);

            // Format and update state with the todos from the server
            const formattedTodos = data.items.map((item) => ({
                id: item.id,
                text: item.name,
                isComplete: item.done,
            }));

            // Update state with the new todos
            setTodos(formattedTodos);
        } catch (error) {
            handleError(error, 'Failed to fetch todos from the server.');
        }
    }

    // Fetch initial data when the React component mounts for the first time.
    useEffect(() => {
        // Call the fetchAndUpdateTodos function when the component mounts
        fetchAndUpdateTodos();
    }, []);

    // Function to add a new todo
    async function addTodo(todo) {
        // Verify the input to prevent adding empty todos
        if (!todo.text) {
            return;
        }

        // Check for duplicate todos
        const isDuplicate = todos.some((t) => t.text === todo.text);   
        if (isDuplicate) {
            setDuplicateTodoError(`"${todo.text}" already exists.`);    // Set the duplicate todo error message
            return;
        } else {
            setDuplicateTodoError(''); // Clear the duplicate todo error message
        }


        // Try sending a POST request to the server to add the new todo
        try {
            const response = await fetch(API_BASE_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name: todo.text,
                }),
            });

            // If the response is anything other than ok, return an error
            if (!response.ok) {
                throw new Error("Failed to add todo on the server.");
            }

            const data = await response.json();

            // Log server response
            logServerResponse(data);

            // Create a new todo object
            const newTodo = {
                id: data.item.id,
                text: data.item.name,
                isComplete: data.item.done,
            };

            // Update state with the new todo
            setTodos((prevTodos) => [newTodo, ...prevTodos]);
        } catch (error) {
            handleError(error, "Failed to add todo on the server.");
        }
    }

    // Function to edit a todo by ID
    async function editTodo(todoId, newText) {
        try {
            const todoToUpdate = todos.find((todo) => todo.id === todoId);

            // Check if newText is empty, if so, do not update anything
            if (!newText || todoToUpdate.isComplete) {
                return;
            }

            // Send a PUT request to the server to update the task text
            const response = await fetch(`${API_BASE_URL}${todoId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name: newText,
                }),
            });

            // If the response is not ok, throw an error
            if (!response.ok) {
                throw new Error("Failed to update todo on the server.");
            }

            const data = await response.json();

            logServerResponse(data);

            // Update the state immediately with the updated todo
            setTodos((prevTodos) =>
                prevTodos.map((item) => (item.id === todoId ? { ...item, text: newText } : item))
            );
        } catch (error) {
            handleError(error, "Failed to update todo on the server.");
        }
    }

    // Function to delete a todo
    async function deleteTodo(id) {
        // Send a DELETE request to the server to delete the todo
        try {
            const response = await fetch(`${API_BASE_URL}${id}`, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                },
            });

            if (!response.ok) {
                throw new Error("Failed to delete todo on the server NOOOO.");
            }

            const data = await response.json();
            logServerResponse(data);

            setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
        } catch (error) {
            handleError(error, "Failed to delete todo on the server MIIPPPP.");
        }
    }

    // Function to mark a todo as complete or incomplete
    async function completeTodo(id) {
        const todoToUpdate = todos.find((todo) => todo.id === id);
        if (!todoToUpdate) {
            return;
        }

        // Create an updated todo with the opposite completion status
        try {
            const updatedTodo = {
                ...todoToUpdate,
                isComplete: !todoToUpdate.isComplete,
            };

            // Send a PUT request to the server to update the todo status
            const response = await fetch(`${API_BASE_URL}${id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name: updatedTodo.text,
                    done: updatedTodo.isComplete,
                }),
            });

            if (!response.ok) {
                throw new Error("Failed to update todo status on the server.");
            }

            const data = await response.json();
            logServerResponse(data);

            // Update the state immediately with the updated todo
            setTodos((prevTodos) =>
                prevTodos.map((item) => (item.id === id ? updatedTodo : item))
            );
        } catch (error) {
            handleError(error, "Failed to update todo status on the server.");
        }
    }

    // Function to clear all todos
    const clearTodos = async () => {
        try {
            // Loop through each todo and send a DELETE request to remove it
            for (const todo of todos) {
                const response = await fetch(`${API_BASE_URL}${todo.id}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (!response.ok) {
                    throw new Error(`Failed to clear all todos on the server.`);
                }

                const data = await response.json();
                logServerResponse(data);
            }

            // Clear the todos in the state
            setTodos([]);
        } catch (error) {
            handleError(error, `Failed to clear all todos on the server RIP.`);
        }
    };

    return (
        <div>
            {/* Header for the top of the ToDo-list */}
            <h1>Task for the day {'<3'}</h1>

            {/* Display error message if there is one */}
            {errorMessage && (
                <div className="error-message">
                    {errorMessage}
                </div>
            )}

            {/* Display duplicate todo error message if there is one */}
            {duplicateTodoError && (
                <div className="error-message">
                    {duplicateTodoError}
                </div>
            )}

            {/* Create the TodoForm component and send the 'addTodo' callback in the rendering process. */}
            <TodoForm onSubmit={addTodo} />

            {/* Render the Todo component and pass various props for managing todos */}
            <Todo
                todos={todos}
                completeTodo={completeTodo}
                deleteTodo={deleteTodo}
                editTodo={editTodo}
            />

            {/* Button to clear all todos */}
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '16px' }}>
                <button onClick={clearTodos} className="clear-button">
                    Clear All Todos
                </button>
            </div>
        </div>
    );
}

export default TodoList;
