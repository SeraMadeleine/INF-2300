/* 
    TodoItem.js is responsible for displaying individual task items and collaborates with 
    Todo.js to handle task completion, deletion, and editing.
*/

import React from 'react';
import { AiOutlineCheckSquare, AiTwotoneDownSquare } from 'react-icons/ai';
import { RiCloseCircleLine } from 'react-icons/ri';
import { TiEdit } from 'react-icons/ti';

function TodoItem({ todo, completeTodo, deleteTodo, editTodo, setEditTodoData }) {
    // Determine if the todo item is completed based on its 'isComplete' property.
    const isCompleted = todo.isComplete;
    
    // Define a CSS class for the todo text element to style it based on completion status.
    const todoTextClass = `todo-text ${isCompleted ? 'complete' : ''}`;
    
    // Create React elements for icons used in the component.
    const doneIcon = (
        <AiOutlineCheckSquare className="done-icon" style={{ marginRight: '8px' }} />
    );
    const notDoneIcon = (
        <AiTwotoneDownSquare className="not-done-icon" style={{ marginRight: '8px' }} />
    );

    // Render the TodoItem component.
    return (
        <div className={`todo-row ${isCompleted ? 'completed' : ''}`}>
            <div className="todo-icon" onClick={() => completeTodo(todo.id)}>
                {/* Display the appropriate icon based on completion status */}
                {isCompleted ? doneIcon : notDoneIcon}
                {/* Display the todo text with the corresponding class */}
                <span className={todoTextClass}>{todo.text}</span>
            </div>
            <div className="icons">
                {/* Add a delete icon that triggers the deleteTodo function */}
                <RiCloseCircleLine onClick={() => deleteTodo(todo.id)} className="delete-icon" />
                {/* Conditionally add an edit icon only if the todo is not completed */}
                {!isCompleted && (
                    <TiEdit onClick={() => setEditTodoData({ id: todo.id, value: todo.text })} className="edit-icon" />
                )}
            </div>
        </div>
    );
}

export default TodoItem;
