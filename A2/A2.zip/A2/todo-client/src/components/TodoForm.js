/*
    TodoList.js is the top-level component that orchestrates the application's functionality, 
    including fetching tasks from a server, error handling, and communication with Todo.js for 
    adding, editing, completing, and deleting tasks.
*/

import React, { useState, useRef } from 'react';
import { AiOutlineCheckSquare, AiTwotoneDownSquare } from 'react-icons/ai';
import { RiCloseCircleLine } from 'react-icons/ri';
import { TiEdit } from 'react-icons/ti';
import axios from 'axios';

// Initialize the Axios instance for API requests
const api = axios.create({
    baseURL: "http://localhost:5000/api/",
});

function TodoForm(props) {
    // Initialize state for input text and todos
    const [inputText, setInputText] = useState(props.edit ? props.edit.value : '');
    const [todos, setTodos] = useState([]);

    // Create a ref for the input element
    const inputRef = useRef(null);

    function handleServerError(error) {
        console.error(error.message);
        alert(`An error occurred: ${error.message}`);
    }

    // Handle input change by updateinng the input text state based on user input
    const handleInputChange = (e) => {
        setInputText(e.target.value);      
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();             // Prevent the browser from reloading/refreshing
        
        // If the input is empty or contains only whitespace, return
        if (!inputText.trim()) {
            return;
        }

        if (props.edit) {
            // If editing, call the editTodo function
            props.onSubmit(inputText);
        } else {
            // If adding, call the addTodo function
            props.onSubmit({
                text: inputText,
            });
        }

        setInputText('');
    };

    // Function to remove a todo by ID
    const handleRemove = (id) => {
        // Remove the todo with the specified ID from the todos list
        const updatedTodos = todos.filter((todo) => todo.id !== id);
        setTodos(updatedTodos);
    };

    // Function to edit a todo by ID
    const handleEdit = async (id, newText) => {
        try {
            // Send a PUT request to the server to update the task
            const response = await api.put(`/items/${id}`, {
                name: newText,
            });

            // Handle response status
            if (response.status !== 200) {
                throw new Error('Failed to edit todo on the server.');
            }

            // Update the local state with the edited todo
            const updatedTodo = { id, name: newText, done: false };
            const updatedTodos = todos.map((todo) =>
                todo.id === id ? updatedTodo : todo
            );
            setTodos(updatedTodos);
        } catch (error) {
            handleServerError(error);
        }
    };

    // Function to mark a todo as done or not done
    const handleDone = (id) => {
        // Mark the todo as done or not done
        const updatedTodos = todos.map((todo) =>
            todo.id === id ? { ...todo, done: !todo.done } : todo
        );
        setTodos(updatedTodos);
    };

    return (
        <div className='todo-form'>
            <form onSubmit={handleSubmit}>
                {props.edit ? (
                    <>
                        <input
                            placeholder='Update your item'
                            value={inputText}
                            onChange={handleInputChange}
                            name='text'
                            ref={inputRef}
                            className='todo-input edit'
                        />
                        <button onClick={handleSubmit} className='todo-button edit'>
                            Update
                        </button>
                    </>
                ) : (
                    <>
                        <input
                            placeholder='Add a todo'
                            value={inputText}
                            onChange={handleInputChange}
                            name='text'
                            className='todo-input'
                            ref={inputRef}
                        />
                        <button onClick={handleSubmit} className='todo-button'>
                            Add todo
                        </button>
                    </>
                )}
            </form>

            {/* Display todos with remove, edit, and done icons */}
            <div className="all-todos">
                <ul>
                    {todos.map((todo) => (
                        <li className={`todo-row ${todo.done ? 'completed' : ''}`} key={todo.id}>
                            <div className="todo-icon" onClick={() => handleDone(todo.id)}>
                                {todo.done ? (
                                    <AiOutlineCheckSquare
                                        className="done-icon"
                                        style={{ marginRight: '8px' }}
                                    />
                                ) : (
                                    <AiTwotoneDownSquare
                                        className="not-done-icon"
                                        style={{ marginRight: '8px' }}
                                    />
                                )}
                                <span className={`todo-text ${todo.done ? 'complete' : ''}`}>
                                    {todo.name}
                                </span>
                            </div>
                            <div className="icons">
                                <RiCloseCircleLine
                                    onClick={() => handleRemove(todo.id)}
                                    className="delete-icon"
                                />
                                <TiEdit
                                    onClick={() => handleEdit(todo.id, 'New Text')}
                                    className="edit-icon"
                                />
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}

export default TodoForm;
