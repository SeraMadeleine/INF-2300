/* 
    Todo.js is the main component responsible for handling the display of the main task list and collaborates with 
    TodoItem.js, TodoForm.js, and TodoList.js to manage task addition, editing, completion, and deletion.
*/

import React, { useState } from 'react';
import TodoForm from './TodoForm';
import TodoItem from './TodoItem';

export default function Todo({
    todos,
    completeTodo,
    deleteTodo,
    editTodo,
    }) {

    // State to manage editing a todo
    const [editTodoData, setEditTodoData] = useState({
        id: null,       // ID of the todo being edited
        value: '',      // Text of the todo being edited
    });

    // Function to submit an edited todo
    const submitUpdate = (editedText) => {
        // Call the editTodo function with the given ID and edited text
        editTodo(editTodoData.id, editedText);
        // Reset the editTodoData state
        setEditTodoData({
        id: null,
        value: '',
        });
    };

    // Function to render a single todo item
    const renderTodo = (todo, index) => (
        <TodoItem
        key={index}                         
        todo={todo}                        
        completeTodo={completeTodo}         
        deleteTodo={deleteTodo}
        editTodo={editTodo}
        setEditTodoData={setEditTodoData}
        />
    );

    // Separate completed and not completed todos
    const notDoneTodos = todos.filter((todo) => !todo.isComplete);
    const doneTodos = todos.filter((todo) => todo.isComplete);

    return (
        <div>
        {notDoneTodos.map(renderTodo)}
        {doneTodos.length > 0 ? (
            <div className="completed-todos">
            {doneTodos.map(renderTodo)}
            </div>
        ) : null}
        {editTodoData.id && (
            <TodoForm edit={editTodoData} onSubmit={submitUpdate} />
        )}
        </div>
    );
    }
